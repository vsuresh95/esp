soc_loc_t cpu_locs[1] = {{1,2}};

soc_loc_t mem_locs[1] = {{1,1}};

soc_loc_t acc_locs[8] = {{0,0}, {0,1}, {0,2}, {0,3}, {1,0}, {1,3}, {2,1}, {2,2}};

unsigned int acc_has_l2[8] = {1, 1, 1, 1, 1, 1, 1, 1};
