soc_loc_t cpu_locs[1] = {{2,1}};

soc_loc_t mem_locs[1] = {{1,1}};

soc_loc_t acc_locs[8] = {{0,0}, {0,2}, {1,0}, {1,2}, {2,0}, {2,2}, {3,0}, {3,1}};

unsigned int acc_has_l2[8] = {1, 1, 1, 1, 1, 1, 1, 1};
