#ifndef __MMI64_REGS_H__
#define __MMI64_REGS_H__

#define DDRS_NUM 1
#define MEMS_NUM 1
#define NOCS_NUM 2
#define TILES_NUM 12
#define XLEN 3
#define YLEN 4
#define ACCS_NUM 5
#define VF_OP_POINTS 4
#define DIRECTIONS 5
#define L2S_NUM 6
#define LLCS_NUM 1
#define MONITOR_REG_COUNT 0
#define MONITOR_RESET_offset 0
#define MONITOR_WINDOW_SIZE_offset 1
#define MONITOR_WINDOW_LO_offset 2
#define MONITOR_WINDOW_HI_offset 3
#define TOTAL_REG_COUNT 4

struct local_yx {
unsigned y;
unsigned x;
};

enum tile_type {
empty_tile,
cpu_tile,
accelerator_tile,
misc_tile,
memory_tile,
};

struct tile_info {
unsigned id;
int type;
struct local_yx position;
char *name;
int has_pll; /* this tile's PLL drives all tiles in the domain */
int domain; /* if 0 then no DVFS */
int domain_master; /* ID of the tile where the PLL for this domain is located */
};

const struct tile_info tiles[TILES_NUM] = {
	{0, 3, {0, 0}, "IO", 0, 0, 0 },
	{1, 0, {0, 1}, "empty", 0, 0, 0 },
	{2, 2, {0, 2}, "GEMM_STRATUS", 0, 0, 0 },
	{3, 2, {1, 0}, "GEMM_STRATUS", 0, 0, 0 },
	{4, 4, {1, 1}, "mem", 0, 0, 0 },
	{5, 2, {1, 2}, "GEMM_STRATUS", 0, 0, 0 },
	{6, 2, {2, 0}, "SORT_STRATUS", 0, 0, 0 },
	{7, 1, {2, 1}, "cpu", 0, 0, 0 },
	{8, 2, {2, 2}, "SORT_STRATUS", 0, 0, 0 },
	{9, 0, {3, 0}, "empty", 0, 0, 0 },
	{10, 0, {3, 1}, "empty", 0, 0, 0 },
	{11, 0, {3, 2}, "empty", 0, 0, 0 }
};

#endif /*  __MMI64_REGS_H__ */
