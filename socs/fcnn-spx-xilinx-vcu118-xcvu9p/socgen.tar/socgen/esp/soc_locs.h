soc_loc_t cpu_locs[1] = {{2,1}};

soc_loc_t mem_locs[1] = {{1,1}};

soc_loc_t acc_locs[5] = {{0,2}, {1,0}, {1,2}, {2,0}, {2,2}};

unsigned int acc_has_l2[5] = {1, 1, 1, 1, 1};
